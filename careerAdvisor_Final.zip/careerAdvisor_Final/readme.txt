Tools used: Webflow and Brackets
Language used: html, CSS, javascript and jquery

How to Run the APP:
Open the index.html to interact with the app.
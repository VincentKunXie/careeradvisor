function submitStep1 (){
    alert('Your information has been saved!');
    document.getElementById("step").innerHTML="Step 2/3";
    var step2text = 
        "<b>Step 2:</b> you can skip this step or you can <b> edit this list of qualifications</b><br>that you need to acquire before you graduate <b>in order to qualify for your chosen career.</b>";
    document.getElementById("step1").innerHTML=step2text;
//    document.getElementById("form1").style.display="none";
    document.getElementById("form1").style.display="none";
    document.getElementById("quali").style.display="block";
    document.getElementById("mytimeline").style.display="none";
    document.getElementById("foot").style.display="none";
    document.getElementById("stepicon").src="./planimages/step2_icon.png";
}

function backStep1 (){
    document.getElementById("step").innerHTML="Step 1/3";
    var step1text = 
        "<b>Step 1:</b> To get started, lets <b>gather some info on your degree.</b><br>CareerAdvisor will then use this info to generate a plan that you can edit.";
    document.getElementById("step1").innerHTML=step1text;
    document.getElementById("form1").style.display="block";
    document.getElementById("quali").style.display="none";
    document.getElementById("mytimeline").style.display="none";
    document.getElementById("foot").style.display="none";
    document.getElementById("stepicon").src="./planimages/step1_icon.png";

}

function editContent (){
    document.getElementById("qualitxt").contentEditable="true";
    document.getElementById("done").style.display="inline-block";
    document.getElementById("editbtn").style.display="none";
    document.getElementById("qualitxt").style.background="lightgrey"
}

function finishEdit (){
   
    document.getElementById("qualitxt").contentEditable="false";
    document.getElementById("done").style.display="none";
    document.getElementById("editbtn").style.display="inline-block";
    document.getElementById("qualitxt").style.background="ghostwhite"

}

function gotoStep3 (){
    document.getElementById("step").innerHTML="4 <br>\Year Plan";
    document.getElementById("vt").innerHTML="";
    var step3text = 
        "<b>Here's Your Timeline of When to Acquire Qualifications:</b>";
    document.getElementById("step1").innerHTML=step3text;
//    document.getElementById("form1").style.display="none";
//    document.getElementById("quali").style.display="none";
    document.getElementById("form1").style.display="none";
    document.getElementById("quali").style.display="none";
    document.getElementById("mytimeline").style.display="block";
    document.getElementById("foot").style.display="block";
    document.getElementById("stepicon").style.display="none";

}

function backStep2 (){
    document.getElementById("step").innerHTML="Step 2/3";
    document.getElementById("vt").innerHTML="Plan Creation <br>\ in Progress";

    var step2text = 
        "<b>Step 2:</b> you can skip this step or you can <b> edit this list of qualifications</b><br>that you need to acquire before you graduate in order to qualify for your chosen career.";
    document.getElementById("step1").innerHTML=step2text;
    document.getElementById("mytimeline").style.display="none";
    document.getElementById("form1").style.display="none";
    document.getElementById("quali").style.display="block";
    document.getElementById("foot").style.display="none";
    document.getElementById("stepicon").style.display="inline-block";
    document.getElementById("stepicon").src="./planimages/step2_icon.png";

}

// vis Timeline ************************************************
// DOM element where the Timeline will be attached
//  var container = document.getElementById('visualization');
//  var s=document.getElementById('st').value;
//  var e=document.getElementById('ed').value;
//    debugger;
// Create a DataSet (allows two way data-binding)
//  var items = new vis.DataSet([
//    
//    {id: 1, content: 'Year 1 Semester 1', start: '2013-09-08', end: '2013-12-22'},
//    {id: 2, content: 'Year 1 Semester 2', start: '2014-01-08', end: '2014-04-28'},
//    {id: 3, content: 'Year 1 Summer', start: '2014-04-29', end: '2014-09-07'},
//      
//    {id: 4, content: 'Year 2 Semester 1', start: '2014-09-08', end: '2014-12-22'},
//    {id: 5, content: 'Year 2 Semester 2', start: '2015-01-08', end: '2015-04-28'},
//    {id: 6, content: 'Year 2 Summer', start: '2015-04-29', end: '2015-09-07'},
//      
//    {id: 7, content: 'Year 3 Semester 1', start: '2015-09-08', end: '2015-12-22'},
//    {id: 8, content: 'Year 3 Semester 2', start: '2016-01-08', end: '2016-04-28'},
//    {id: 9, content: 'Year 3 Summer', start: '2016-04-29', end: '2016-09-07'},
//      
//    {id: 10, content: 'Year 4 Semester 1', start: '2016-09-08', end: '2016-12-22'},
//    {id: 11, content: 'Year 4 Semester 2', start: '2017-01-08', end: '2017-04-28'},
//    {id: 12, content: 'Year 4 Summer', start: '2017-04-29', end: '2017-09-07'}
//   
//    
//  ]);
//
//  // Configuration for the Timeline
//  var options = {};
//
//  // Create a Timeline
//  var timeline = new vis.Timeline(container, items, options);
// vis Timeline ************************************************


function ActionInfo() {
    this.startDate = null;
    this.length = null;
    this.actionName = null;
    this.skills = [];
    this.experiences = [];
    this.submitInfo = null;
    this.id = null;
}

function SubmitInfo() {
    this.type = 'submit';
    this.startDate = null;
    this.length = null;
    this.actionName = null;
}

var actionInfos = [];
var actionId = 0;

$('#myModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var recipient = button.data('whatever') // Extract info from data-* attributes
    // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
    // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
    var modal = $(this);
    var modalbody = modal.find('.modal-body');
    //	var reqOptions = $('#requirementOptions');
    var reqs = $('#requirements');

    var actionInfo = new ActionInfo();
    actionId += 1;
    actionInfo.actionId = actionId;
    actionInfos.push(actionInfo);

    // education
    if (!reqs.html()) {
        var li = $('#p2edu').find('ul').find('li');
        $('<br>').appendTo(reqs);
        $('<h4>').append('Education').appendTo(reqs);
        $(li).each(function (ind, el) {
            $('<input />', {
                type: 'checkbox',
                value: $(el).text()
            }).appendTo(reqs);
            $('<label/>').append($(el).text()).appendTo(reqs);
            $('<br>').appendTo(reqs);
        });

        // Skills 
        var li = $('#p2skills').find('ul').find('li');
        $('<h4>').append('Skills').appendTo(reqs);
        $(li).each(function (ind, el) {
            $('<input />', {
                type: 'checkbox',
                value: $(el).text(),
                class: 'skills'
            }).appendTo(reqs);
            $('<label/>').append($(el).text()).appendTo(reqs);
            $('<br>').appendTo(reqs);
        });

        // experiences
        var exps = $('#p2exp').children();
        $('<h4>').append('Experiences').appendTo(reqs);
        exps.each(function (i, el) {
            if (el.className === 'expHeading') {
                $('<p>').append($(el).text()).appendTo(reqs);
            }
            if (el.tagName === 'UL') {
                var items = $(el).find('li');
                items.each(function (ind, el) {
                    $('<input />', {
                        type: 'checkbox',
                        value: $(el).text(),
                        class: 'experiences'
                    }).appendTo(reqs);
                    $('<label/>').append($(el).text()).appendTo(reqs);
                    $('<br>').appendTo(reqs);
                })
            }
        });

        $('#requirements :checkbox').on('change', function () {
            var checkbox = $(this);
            var v = checkbox.val();
            if (this.checked) {
                if (checkbox.attr('class') === 'skills') {
                    actionInfos.slice(-1)[0].skills.push(v);
                }
                if (checkbox.attr('class') === 'experiences') {
                    actionInfos.slice(-1)[0].experiences.push(v);
                }
            } else {
                var p = actionInfo.skills.indexOf(v);
                if (checkbox.attr('class') === 'skills') {
                    actionInfos.slice(-1)[0].skills.splice(p, 1);
                }
                if (checkbox.attr('class') === 'experiences') {
                    actionInfos.slice(-1)[0].experiences.splice(p, 1);
                }
            }
        })
    }

    var plans = $('#plans');
    plans.on('change', function (e) {
        var $select = $(this);
        var value = $select.val();
        if (value === 'Full-time Job' || value === 'Part-time Job' || value === 'Preparation Course' || value === 'Online Course') {
            $('#submodal').click();
        }
        actionInfos.slice(-1)[0].actionName = value;
    });
    $('#startMonth').on('change', function () {
        actionInfos.slice(-1)[0].startDate = $(this).val();
    });
    $('#length').on('change', function () {
        actionInfos.slice(-1)[0].length = $(this).val();
    });
    $('#addToTimeline').on('click', function () {
        $('.year .action').remove();
        $('.year .submit').remove();
        actionInfos.forEach(function (el) {
            drawTimeline(el);
            drawTimeline(el.submitInfo);
        });
        console.log('actionInfos:', actionInfos);
    });
});


var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

function drawTimeline(el) {
    var firstYear = actionInfos[0].startDate.split('-')[0];
    if (el !== null && el.actionName !== null) {
        var d = el.startDate;
        var y = d.split('-')[0];
        var diffYear = +y - +firstYear;
        var year = 'year' + diffYear;

        var m = d.split('-')[1];
        var s = null;
        if (+m >= 1 && +m < 5) {
            s = 'semester2';
        } else if (+m >= 5 && +m < 9) {
            s = 'summer';
        } else {
            s = 'semester1';
        }
        $actionSemester = $('#' + year + ' ' + '#' + s);
        
        var actionMark = null;
        if (el.type === 'submit') {
            actionMark = $('<div>', {
                class: 'submit'
            }).appendTo($actionSemester);
        } else {
            actionMark = $('<div>', {
                class: 'action'
            }).appendTo($actionSemester);
        }

        if (s === 'summer') {
            actionMark.addClass('summerTimeline')
        } else {
            actionMark.addClass(s);
        }

        var lastMonth = null;
        if (s === 'semester1') {
            lastMonth = 12;
        } else if (s === 'semester2') {
            lastMonth = 4;
        } else {
            lastMonth = 8;
        }
        var p = 180 * (4 - (lastMonth - +m + 1)) / 4;
        actionMark.css('top', p + 'px');
        var locator = $('<div class="locator">')
        
//      Add Action or Submit Icon to Timeline mark
        if(actionMark.hasClass("action")) {
            var actimg = $('<img />', { src: './planimages/action_icon.png'});
            actimg.attr("height","24");
            actimg.attr("width","24");
        }
        
        if(actionMark.hasClass("submit"))
        {   
            var subimg = $('<img />', { src: './planimages/submit_icon.png'});
            subimg.attr("height","24");
            subimg.attr("width","24");
        }
//      Finish Add Action or Submit Icon to Timeline mark
        
        var startDate = months[+m - 1] + ' 1';
        var endDate = months[+m - 1 + +el.length - 1] + ' 30';

        var dateRange = $('<i id=dataRange>').text(startDate + ' - ' + endDate);
        var actionName = $('<i id=actionName>').text('Action: ' + el.actionName);
        
        var btn = $('<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#detailModal">View Detail</button>')
        btn.attr('data-id', el.actionId);

        var skillsExperiences = '';
        if (el.skills) {
            if (skillsExperiences === '') {
                skillsExperiences += ' Acquire ';
            }
            skillsExperiences += el.skills.length + ' Skills ';
        }
        if (el.experiences) {
            if (skillsExperiences === '') {
                skillsExperiences += ' Acquire ';
            }
            skillsExperiences += el.experiences.length + ' Experiences ';
        }
        actionMark.append(locator).append(actimg).append(subimg).append(dateRange).append('<br>').append(actionName).append('<br>').append(btn).append(skillsExperiences);
    }
}

$('#detailModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var actionId = button.data('id');
    var modal = $(this);
    var body = modal.find('.modal-body');
    body.html('');

    actionInfos.forEach(function (el) {
        if (el.actionId === actionId) {
            if (el.submitInfo) {
                var submitTitle = el.submitInfo.actionName;
                var m = el.submitInfo.startDate.split('-')[1];
                var startDate = months[+m - 1] + ' 1';
                var deadline = months[+m - 1 + +el.submitInfo.length - 1] + ' 30';

                body.append($('<h3>').text('Submission Item: '));
                body.append($('<h4>').text('Title: ' + submitTitle));
                body.append($('<h4>').text('Deadline: ' + deadline));
                body.append($('<h2>').text('Start: ' + startDate));
            }
            var actionTitle = el.actionName;
            var actionMonth = el.startDate.split('-')[1];
            var actionStartDate = months[+actionMonth - 1] + ' 1';

            body.append($('<h3>').text('Action Item: '));
            body.append($('<h4>').text('Title: ' + actionTitle));
            body.append($('<h2>').text('Start: ' + actionStartDate));

            if (el.skills) {

                body.append($('<h4>').text('Skills'));
                var ul = $('<ul>');
                body.append(ul);
                el.skills.forEach(function (el) {
                    ul.append($('<li>').text(el));
                });
            }
            if (el.experiences) {
                body.append($('<h4>').text('Experiences'));
                var ul = $('<ul>');
                body.append(ul);
                el.experiences.forEach(function (el) {
                    ul.append($('<li>').text(el));
                });
            }
        }
    });
    //    }
});

$('#saveSubmit').on('click', function (event) {
    var submitInfo = new SubmitInfo();
    var submitName = $('#submitName').val();
    var submitStartDate = $('#submitStartDate').val();
    var submitLength = $('#submitLength').val();
    submitInfo.actionName = submitName;
    submitInfo.startDate = submitStartDate;
    submitInfo.length = submitLength;
    submitInfo.actionId = actionInfos.slice(-1)[0].actionId;
    actionInfos.slice(-1)[0].submitInfo = submitInfo;
});


//$('#checkList').on('show.bs.modal', function (event) {
//   
//    var button = $(event.relatedTarget) 
//    var recipient = button.data('whatever') 
//    var modal = $(this);
//    var modalbody = modal.find('.modal-body');
//    var reqs = $('#requirements');
//
//    var actionInfo = new ActionInfo();
//    actionId += 1;
//    actionInfo.actionId = actionId;
//    actionInfos.push(actionInfo);
//
//
//        var li = $('#p2edu').find('ul').find('li');
//        $('<br>').appendTo(reqs);
//        $('<h4>').append('Education').appendTo(reqs);
//        $(li).each(function (ind, el) {
//            $('<input />', {
//                type: 'checkbox',
//                value: $(el).text()
//            }).appendTo(reqs);
//            $('<label/>').append($(el).text()).appendTo(reqs);
//            $('<br>').appendTo(reqs);
//        });
//
//        // Skills 
//        var li = $('#p2skills').find('ul').find('li');
//        $('<h4>').append('Skills').appendTo(reqs);
//        $(li).each(function (ind, el) {
//            $('<input />', {
//                type: 'checkbox',
//                value: $(el).text(),
//                class: 'skills'
//            }).appendTo(reqs);
//            $('<label/>').append($(el).text()).appendTo(reqs);
//            $('<br>').appendTo(reqs);
//        });
//
//        // experiences
//        var exps = $('#p2exp').children();
//        $('<h4>').append('Experiences').appendTo(reqs);
//        exps.each(function (i, el) {
//            if (el.className === 'expHeading') {
//                $('<p>').append($(el).text()).appendTo(reqs);
//            }
//            if (el.tagName === 'UL') {
//                var items = $(el).find('li');
//                items.each(function (ind, el) {
//                    $('<input />', {
//                        type: 'checkbox',
//                        value: $(el).text(),
//                        class: 'experiences'
//                    }).appendTo(reqs);
//                    $('<label/>').append($(el).text()).appendTo(reqs);
//                    $('<br>').appendTo(reqs);
//                })
//            }
//        });
//
//        $('#requirements :checkbox').on('change', function () {
//            var checkbox = $(this);
//            var v = checkbox.val();
//            if (this.checked) {
//                if (checkbox.attr('class') === 'skills') {
//                    actionInfos.slice(-1)[0].skills.push(v);
//                }
//                if (checkbox.attr('class') === 'experiences') {
//                    actionInfos.slice(-1)[0].experiences.push(v);
//                }
//            } else {
//                var p = actionInfo.skills.indexOf(v);
//                if (checkbox.attr('class') === 'skills') {
//                    actionInfos.slice(-1)[0].skills.splice(p, 1);
//                }
//                if (checkbox.attr('class') === 'experiences') {
//                    actionInfos.slice(-1)[0].experiences.splice(p, 1);
//                }
//            }
//        })
//});
